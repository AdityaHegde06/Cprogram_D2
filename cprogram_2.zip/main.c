/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

/*write a progrsm to calculate gross salary*/

#include <stdio.h>

int main()
{
 float bp,da,hra,grpay;
 printf("\nEnter Basic Salary of Ramesh:");
 scanf("%f",&bp);
 da=0.4*bp;
 hra=0.2*bp;
 //calculate gross salary
 grpay=bp+da+hra;
 printf("Basic Salary of Ramesh=%f\n",bp);
 printf("Dearness Allowance =%f\n",da);
 printf("House Rent Aloowace =%f\n",hra);
 printf("Gross Pay of Ramesh is %f\n",grpay);
 return 0;
  
}
