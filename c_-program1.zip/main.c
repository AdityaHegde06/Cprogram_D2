/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*calculation simple interst'*/

#include <stdio.h>

int main()
 {
     int p,n;
     float r,si;
     
     printf("enter the  values p,n,r");
     scanf("%d%d%f",&p,&n,&r);
     si=p*n*r/100;
     printf("%f\n",si);
     return 0;
   

    return 0;
}

