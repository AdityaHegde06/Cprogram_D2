/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/*calculate distance between 2 cities  and print  the distance in meters ,feet ,inches*/
#include <stdio.h>

int main()
{
    float km,m,cm,ft,inch;
    printf("\nEnter the Distance in kilometers");
    scanf("%f",&km);
    m=km*1000;
    cm=m*100;
    inch=cm/2.54;
    ft=inch/12;
    printf("Distance in meters= %f\n",m);
     printf("Distance in cm= %f\n",cm);
     printf("Distance in feet= %f\n",ft);
     printf("Distance in inches= %f\n",inch);
     
     return 0;
    
 
 

    return 0;
}
